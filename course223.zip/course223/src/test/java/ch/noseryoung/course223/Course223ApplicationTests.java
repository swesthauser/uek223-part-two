package ch.noseryoung.course223;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Course223ApplicationTests {

	@Test
	void contextLoads() {
	}

}
