package ch.noseryoung.course223;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Course223Application {

	public static void main(String[] args) {
		SpringApplication.run(Course223Application.class, args);
	}

}
