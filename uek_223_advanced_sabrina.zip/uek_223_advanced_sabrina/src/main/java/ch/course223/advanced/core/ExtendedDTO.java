package ch.course223.advanced.core;

public class ExtendedDTO {

	private String id;

	public ExtendedDTO() {}

	public ExtendedDTO(String id) {
		this.id = id;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}
}
